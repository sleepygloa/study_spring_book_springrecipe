package com.dongwon.tmapapi;

public class PointToPointData {
	private String d1Code;
	private String d2Code;
	private PathData pathData;
	
	public String getD1Code() {
		return d1Code;
	}
	public void setD1Code(String d1Code) {
		this.d1Code = d1Code;
	}
	public String getD2Code() {
		return d2Code;
	}
	public void setD2Code(String d2Code) {
		this.d2Code = d2Code;
	}
	public PathData getPathData() {
		return pathData;
	}
	public void setPathData(PathData pathData) {
		this.pathData = pathData;
	}
	
}
